using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DroneAttack : MonoBehaviour
{
    [SerializeField] private GameObject drone;
    [SerializeField] private GameObject bomb;

    public IEnumerator BombExplosion()
    {   
        yield return new WaitForSeconds(3f);
        bomb.SetActive(false);
    }

    public void Attack()
    {
        var x = drone.transform.position.x;
        var y = drone.transform.position.y;
        var rot = drone.transform.localEulerAngles.z;
        if (rot == 90 && x <= 7)
        {
            bomb.transform.position = new Vector2(x + 2, y);
            bomb.SetActive(true);
            StartCoroutine(BombExplosion());
        }
        else if (rot == 180 && y <= 7)
        {
            bomb.transform.position = new Vector2(x, y + 2);
            bomb.SetActive(true);
            StartCoroutine(BombExplosion());
        }
        if (rot == 270 && x >= 2)
        {
            bomb.transform.position = new Vector2(x -2, y);
            bomb.SetActive(true);
            StartCoroutine(BombExplosion());
        }
        if (rot == 0 && y >= 2)
        {
            bomb.transform.position = new Vector2(x, y - 2);
            bomb.SetActive(true);
            StartCoroutine(BombExplosion());
        }
        else
        {
            Debug.Log("Failed!");
        }
    }
}
