using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlaceDrone : MonoBehaviour
{
    [SerializeField] private TMP_InputField rowNumber;
    [SerializeField] private TMP_InputField columnNumber;
    [SerializeField] private TMP_InputField direction;
    [SerializeField] private GameObject drone;
    [SerializeField] private GameObject allControls;
    [SerializeField] private GameObject otherControls;
    [SerializeField] private GameObject placeDetails;
    [SerializeField] private GameObject invalid;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Submit()
    {
        Debug.Log(rowNumber.text + ", " + columnNumber.text + ", " + direction.text);
        int row = int.Parse(rowNumber.text);
        int column = int.Parse(columnNumber.text);
        string dir = direction.text;
        var rot = drone.transform.localEulerAngles.z;
        if (dir == "North" && row >= 0 && row <= 9 && column >= 0 && column <= 9) 
        {
            if (rot == 90)
            {
                drone.transform.Rotate(0, 0, -90);
            }
            else if (rot == 180)
            {
                drone.transform.Rotate(0, 0, -180);
            }
            else if (rot == 270)
            {
                drone.transform.Rotate(0, 0, -270);
            }
            else if (rot == 0)
            {
                drone.transform.Rotate(0, 0, -0);
            }
            drone.transform.Rotate(0, 0, 180);
            drone.transform.position = new Vector2(row, column);
            allControls.SetActive(true);
            otherControls.SetActive(true);
            placeDetails.SetActive(false);
        }
        else if (dir == "West" && row >= 0 && row <= 9 && column >= 0 && column <= 9)
        {
            if (rot == 90)
            {
                drone.transform.Rotate(0, 0, -90);
            }
            else if (rot == 180)
            {
                drone.transform.Rotate(0, 0, -180);
            }
            else if (rot == 270)
            {
                drone.transform.Rotate(0, 0, -270);
            }
            else if (rot == 0)
            {
                drone.transform.Rotate(0, 0, -0);
            }
            drone.transform.Rotate(0, 0, 270);
            drone.transform.position = new Vector2(row, column);
            allControls.SetActive(true);
            otherControls.SetActive(true);
            placeDetails.SetActive(false);
        }
        else if (dir == "South" && row >= 0 && row <= 9 && column >= 0 && column <= 9)
        {
            if (rot == 90)
            {
                drone.transform.Rotate(0, 0, -90);
            }
            else if (rot == 180)
            {
                drone.transform.Rotate(0, 0, -180);
            }
            else if (rot == 270)
            {
                drone.transform.Rotate(0, 0, -270);
            }
            else if (rot == 0)
            {
                drone.transform.Rotate(0, 0, -0);
            }
            drone.transform.Rotate(0, 0, 0);
            drone.transform.position = new Vector2(row, column);
            allControls.SetActive(true);
            otherControls.SetActive(true);
            placeDetails.SetActive(false);
        }
        else if (dir == "East" && row >= 0 && row <= 9 && column >= 0 && column <= 9)
        {
            if (rot == 90)
            {
                drone.transform.Rotate(0, 0, -90);
            }
            else if (rot == 180)
            {
                drone.transform.Rotate(0, 0, -180);
            }
            else if (rot == 270)
            {
                drone.transform.Rotate(0, 0, -270);
            }
            else if (rot == 0)
            {
                drone.transform.Rotate(0, 0, -0);
            }
            drone.transform.Rotate(0, 0, 90);
            drone.transform.position = new Vector2(row, column);
            allControls.SetActive(true);
            otherControls.SetActive(true);
            placeDetails.SetActive(false);
        }
        else
        {
            placeDetails.SetActive(false);
            invalid.SetActive(true);
            Debug.Log("Failed!");
        }
        
    }
}
