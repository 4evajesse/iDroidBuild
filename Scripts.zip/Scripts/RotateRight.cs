using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class RotateRight : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    private bool isPressed;
    public GameObject drone;

    public void OnPointerDown(PointerEventData eventData)
    {
        isPressed = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isPressed = false;
    }

    public void Start()
    {
        isPressed = false;
    }

    public void Update()
    {
        if (isPressed == true)
        {
            drone.transform.Rotate(0, 0, -90);
            isPressed = false;
        }
    }
}
