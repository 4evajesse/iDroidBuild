using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class RotateLeft : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    private bool isPressed;
    public GameObject drone;

    public void OnPointerDown(PointerEventData eventData)
    {
        isPressed = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isPressed = false;
    }

    public void Start()
    {
        isPressed = false;
    }

    public void Update()
    {
        float rot  = rot = drone.transform.localEulerAngles.z;
        if (isPressed == true)
        {
            drone.transform.Rotate(0, 0, 90);
            isPressed = false;
        }
        if (rot == 360 || rot == -360)
        {
            drone.transform.Rotate(0, 0, 0);
        }
    }
}
