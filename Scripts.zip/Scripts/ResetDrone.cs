using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetDrone : MonoBehaviour
{
    [SerializeField] private GameObject drone;

    public void ResetRotation ()
    {
        var rot = drone.transform.localEulerAngles.z;

        if (rot == 90)
        {
            drone.transform.Rotate(0, 0, -90);
        }
        else if (rot == 180)
        {
            drone.transform.Rotate(0, 0, -180);
        }
        else if (rot == 270)
        {
            drone.transform.Rotate(0, 0, -270);
        }
        else if (rot == 0)
        {
            drone.transform.Rotate(0, 0, -0);
        }
    }
}
