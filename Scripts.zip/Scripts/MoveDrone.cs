using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveDrone : MonoBehaviour
{
    [SerializeField] private GameObject drone;
    private float rot;
    private float x;
    private float y;

    // Start is called before the first frame update
    public void Move()
    {
        rot = drone.transform.localEulerAngles.z;
        x = drone.transform.position.x;
        y = drone.transform.position.y;
        if (rot == 90 && x < 9)
        {
            drone.transform.position = new Vector2(x+1, y);
        }
        else if (rot == 180 && y < 9)
        {
            drone.transform.position = new Vector2(x, y + 1);
        }
        else if (rot == 270 &&  x > 0)
        {
            drone.transform.position = new Vector2(x - 1, y);
        }
        else if (rot == 0 && y > 0)
        {
            drone.transform.position = new Vector2(x, y - 1);
        }
        else
        {
            Debug.Log("Failed!");
        }
    }
}
