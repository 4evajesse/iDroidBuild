using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DroneLocation : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI outputResult;
    [SerializeField] private GameObject drone;
    
    public void Report()
    {
        var x = drone.transform.position.x;
        var y = drone.transform.position.y;
        var rot = drone.transform.localEulerAngles.z;
        if (rot == 90 || rot == -270)
        {
            string dir = "East";
            outputResult.text = "(" + x + ", " + y + ", " + dir + ")";
        }
        else if (rot == 180 || rot == -180)
        {
            string dir = "North";
            outputResult.text = "(" + x + ", " + y + ", " + dir + ")";
        }
        else if (rot == 270 || rot == -90)
        {
            string dir = "West";
            outputResult.text = "(" + x + ", " + y + ", " + dir + ")";
        }
        else if (rot == 0)
        {
            string dir = "South";
            outputResult.text = "(" + x + ", " + y + ", " + dir + ")";
        }
    }
}
